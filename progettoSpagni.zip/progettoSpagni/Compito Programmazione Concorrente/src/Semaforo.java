public class Semaforo {
    /**
     * intero che determina il valore del semaforo
     */
    private int valore;

    /**
     * Costruttore del Semaforo
     * @param valore intero assegnato alla variabile semaforo
     */
    public Semaforo(int valore) {
        this.valore = valore;
    }
    
    /**
     * Se il valore è uguale a zero allora manderà una stampa d'attesa e metterà in attesa il Thread
     * Se il valore è diverso da zero allora diminuirà il valore
     */
    public synchronized void P(){
        while(valore == 0){
            try {
                System.out.println("----------" + Thread.currentThread().getName() + " sta aspettando ai box----------");
                wait();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        valore--;
    }

    /**
     * Aumenta il valore e sveglia il primo thread che è in attesa
     */
    public synchronized void V(){
        valore++;
        notify();
    }
}
