public class Pit_Stop {
    
    public void usa(String nome){
        System.out.println("PIT-STOP " + nome + " cambio gomme in corso");
    }

    public void concluso(String nome){
        System.out.println("PIT-STOP " + nome + " FINITO");
    }
}
