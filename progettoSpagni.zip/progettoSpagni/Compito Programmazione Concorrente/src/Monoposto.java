public class Monoposto extends Thread{
    
    private int identificativo;
    private String scuderia;
    private String pilota;
    private Pit_Stop p;
    private Semaforo s;


    public Monoposto(int identificativo, String scuderia, String pilota, Pit_Stop p, Semaforo s) {
        super(pilota);
        this.identificativo = identificativo;
        this.scuderia = scuderia;
        this.pilota = pilota;
        this.p = p;
        this.s = s;
    }

    @Override
    public void run() {
        int cont = 0;
        try{
            for(int i = 0; i < 10; i++){
                Thread.sleep(tempo(4));
                System.out.println("GIRO-" + (i+1) + " COMPLETATO " + pilota);
                cont++;
                if(cont%3 == 0 && cont != 0){
                    s.P();
                    p.usa(pilota);
                    sleep(tempo(5));
                    p.concluso(pilota);
                    s.V();
                    cont = 0;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
    }

    private int tempo(int n){
        return (int) (Math.random()*n*1000+1);
    }
}
