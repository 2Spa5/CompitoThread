public class App {
    public static void main(String[] args) throws Exception {
        Pit_Stop p = new Pit_Stop();
        Semaforo s = new Semaforo(1);

        Monoposto m1 = new Monoposto(25, "Mercedes", "Hamilton", p, s);
        Monoposto m2= new Monoposto(39, "Red Bull", "Suarez", p, s);
        Monoposto m3 = new Monoposto(89, "Pagani", "Rossi", p, s);

        m1.start();
        m2.start();
        m3.start();
        m1.join();
        m2.join();
        m3.join();

        System.out.println("FINE GARA");
    }
}
